class ActivationUnit(object):
    def __init__(self):
        pass

    def activation(self):
        pass