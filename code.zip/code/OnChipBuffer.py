class OnChipBuffer(object):
    def __init__(self):
        pass

    def onChipBufferToWL(self):
        pass