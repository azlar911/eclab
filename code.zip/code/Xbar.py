class Xbar(object):
    def __init__(self, xbar_h, xbar_w, OU_h, OU_w):
        self.xbar_h = xbar_h
        self.xbar_w = xbar_w
        self.OU_h = OU_h
        self.OU_w = OU_w

    def OperationUnit(self):
        pass