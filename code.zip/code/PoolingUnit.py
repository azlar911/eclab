class PoolingUnit(object):
    def __init__(self, h, w):
        self.height = h
        self.weight = w
        
    def pooling(self):
        pass