class BitShiftAndAdd(object):
    def __init__(self):
        pass

    def bSAA(self):
        pass