class InputShiftAndAdd(object):
    def __init__(self):
        pass

    def inputSAA(self):
        pass